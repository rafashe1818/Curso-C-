using System;

class Program
{
    static void Main(string[] args)
    {
        Random aleatorio = new Random();
        int numeroAleatorio = aleatorio.Next(1, 101);
        int tentativas = 0;

        Console.WriteLine("======== Missão 007: Descubra a senha secreta do cofre =========");
      Console.WriteLine("");
      
        Console.WriteLine("Você tem 10 tentativas para adivinhar a senha entre 1 e 100");
        

        while (tentativas <= 10)
        {
          Console.WriteLine("");
            Console.Write("Digite a senha: ");
            int senha = int.Parse(Console.ReadLine());
            tentativas++;

            if (senha < numeroAleatorio)
                Console.WriteLine("Errou o número é MAIOR.");
          else if (senha > numeroAleatorio)
                Console.WriteLine("Errou o número é MENOR.");
            else
            {
              Console.WriteLine("");
                Console.WriteLine($"Acertou! Você abriu o cofre em {tentativas} tentativas.");
                return;
            }
        }

      Console.WriteLine("");

        Console.WriteLine($"Você atingiu o limite de tentativas a policia chegou. a senha era {numeroAleatorio}.");
    }
}